nature Displacement
access = disp;
units = "m"; 
abstol = 1.0e-9;
endnature

nature Force
access = frc;
units = "N"; 
abstol = 1.0e-9;
endnature

nature Velocity
access = vel;
units = "m/s"; 
abstol = 1.0e-3;
blowup = 1.0e+12;
endnature

nature Angular_Velocity
access = avel;
units = "rad/s"; 
abstol = 1.0e-3;
blowup = 1.0e+12;
endnature

nature Angle
access = ang;
units = "rad"; 
abstol = 1.0e-3;
endnature

nature Torque
access = trq;
units = "N*m"; 
abstol = 1.0e-3;
endnature

nature Acceleration
access = acc;
units = "m/s^2"; 
abstol = 1.0e-3;
blowup = 1.0e+12;
endnature

nature Angular_Acceleration
access = aacc;
units = "rad/s^2"; 
abstol = 1.0e-3;
blowup = 1.0e+12;
endnature

nature Voltage
access = V;
units = "V"; 
abstol = 1.0e-6;
blowup = 1.0e+12;
endnature

nature Current
access = I;
units = "A"; 
abstol = 1.0e-6;
blowup = 1.0e+12;
endnature

//nature Voltage_Derivative
//access = DV;
//units = "V/s"; 
//abstol = 1.0e-9
//blowup = 1.0e+12;
//endnature

discipline mechanical_linear
potential Displacement;
flow Force;
enddiscipline

discipline mechanical_angular
potential Angle;
flow Torque;
enddiscipline

discipline mechanical_linear_velocity
potential Velocity;
flow Force;
enddiscipline

discipline mechanical_angular_velocity
potential Angular_Velocity;
flow Torque;
enddiscipline

discipline mechanical_linear_acceleration
potential Acceleration;
flow Force;
enddiscipline

discipline mechanical_angular_acceleration
potential Angular_Acceleration;
flow Torque;
enddiscipline

discipline electrical
potential Voltage;
flow Current;
enddiscipline

